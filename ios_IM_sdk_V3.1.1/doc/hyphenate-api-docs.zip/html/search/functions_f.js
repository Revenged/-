var searchData=
[
  ['searchpublicgroupwithid_3aerror_3a',['searchPublicGroupWithId:error:',['../protocol_i_e_m_group_manager-p.html#a6bb1222214e0f15ce1034da4be30a55f',1,'IEMGroupManager-p']]],
  ['setapnsnickname_3a',['setApnsNickname:',['../interface_e_m_client.html#a29f928aab2d104e6bf00426ed0c3d7dc',1,'EMClient']]],
  ['sharedclient',['sharedClient',['../interface_e_m_client.html#abdf7f014fc5a6c76d9a9bd676d9543f5',1,'EMClient']]],
  ['startvideorecord_3a',['startVideoRecord:',['../interface_e_m_call_session.html#a8be657b36ec9ed51e91d98aefcc522b3',1,'EMCallSession']]],
  ['stopvideorecord',['stopVideoRecord',['../interface_e_m_call_session.html#af023d9a8c8163519ade3040ceb8abe90',1,'EMCallSession']]]
];
