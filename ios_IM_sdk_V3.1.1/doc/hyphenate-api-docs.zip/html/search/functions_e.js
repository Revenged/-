var searchData=
[
  ['registerwithusername_3apassword_3a',['registerWithUsername:password:',['../interface_e_m_client.html#a1bb2e72b995535670e8ac74f88b1038e',1,'EMClient']]],
  ['removedelegate_3a',['removeDelegate:',['../interface_e_m_client.html#a91a88bc50b7d313c1c4ec43e9d075c33',1,'EMClient::removeDelegate:()'],['../protocol_i_e_m_call_manager-p.html#aa9b3da07b69c09e892f828791b1370cb',1,'IEMCallManager-p::removeDelegate:()'],['../protocol_i_e_m_chat_manager-p.html#a793b5dbec286331da5e92c557a0ef645',1,'IEMChatManager-p::removeDelegate:()'],['../protocol_i_e_m_chatroom_manager-p.html#a5efdb1d5d2b5e9dd861bcf726d481a02',1,'IEMChatroomManager-p::removeDelegate:()'],['../protocol_i_e_m_contact_manager-p.html#abd575c93a9e96bc19ae74cfd43a3a3fd',1,'IEMContactManager-p::removeDelegate:()'],['../protocol_i_e_m_group_manager-p.html#a9441acba099c3de31122bbfbee611149',1,'IEMGroupManager-p::removeDelegate:()']]],
  ['removeoccupants_3afromgroup_3aerror_3a',['removeOccupants:fromGroup:error:',['../protocol_i_e_m_group_manager-p.html#a0357dbe220d81a9728e26c1aa4129e68',1,'IEMGroupManager-p']]],
  ['removeuserfromblacklist_3a',['removeUserFromBlackList:',['../protocol_i_e_m_contact_manager-p.html#a3d7ecfcf4e0a7446ae268d4656e9b7f7',1,'IEMContactManager-p']]],
  ['resumevideotransfer_3a',['resumeVideoTransfer:',['../protocol_i_e_m_call_manager-p.html#aef61306d78bd1e2159414cf787b3c669',1,'IEMCallManager-p']]],
  ['resumevoiceandvideotransfer_3a',['resumeVoiceAndVideoTransfer:',['../protocol_i_e_m_call_manager-p.html#a67b4b2687296536983e381bdaf5d934f',1,'IEMCallManager-p']]],
  ['resumevoicetransfer_3a',['resumeVoiceTransfer:',['../protocol_i_e_m_call_manager-p.html#a79acc4be766541ab98e3f909e78c0bbf',1,'IEMCallManager-p']]]
];
