var searchData=
[
  ['latestmessagefromothers',['latestMessageFromOthers',['../interface_e_m_conversation.html#aedadc24a089c35ceba41bd87a8eb2f98',1,'EMConversation']]],
  ['leavechatroom_3aerror_3a',['leaveChatroom:error:',['../protocol_i_e_m_chatroom_manager-p.html#a7b8a4a9d3627a3070569b50ba78125e7',1,'IEMChatroomManager-p']]],
  ['leavegroup_3aerror_3a',['leaveGroup:error:',['../protocol_i_e_m_group_manager-p.html#a7ddf033ceaa8bbe34d53f6904f22ab5f',1,'IEMGroupManager-p']]],
  ['loadallconversationsfromdb',['loadAllConversationsFromDB',['../protocol_i_e_m_chat_manager-p.html#aa7f112da8fe1ee49c9749c417e1186cf',1,'IEMChatManager-p']]],
  ['loadallmygroupsfromdb',['loadAllMyGroupsFromDB',['../protocol_i_e_m_group_manager-p.html#ad32a1e1830d5d858b9d9c7eae31fc1fe',1,'IEMGroupManager-p']]],
  ['loadmessagewithid_3a',['loadMessageWithId:',['../interface_e_m_conversation.html#acb5a2ad74dda943f56f7da4585f2a1a5',1,'EMConversation']]],
  ['loadmoremessagescontain_3abefore_3alimit_3a',['loadMoreMessagesContain:before:limit:',['../interface_e_m_conversation.html#add07b6ce7d0ba39c5afd2771d963b618',1,'EMConversation']]],
  ['loadmoremessagesfromid_3alimit_3a',['loadMoreMessagesFromId:limit:',['../interface_e_m_conversation.html#a3815dafb0dd54337a581132419cdde2c',1,'EMConversation']]],
  ['loadmoremessageswithtype_3abefore_3alimit_3a',['loadMoreMessagesWithType:before:limit:',['../interface_e_m_conversation.html#a60e02ababff7f6e8816a633d2db42de5',1,'EMConversation']]],
  ['loginwithusername_3apassword_3a',['loginWithUsername:password:',['../interface_e_m_client.html#a586c4bdeb649055886c25603125072fe',1,'EMClient']]],
  ['logout_3a',['logout:',['../interface_e_m_client.html#ab4562627674072e4b2a98ece2d429efb',1,'EMClient']]]
];
