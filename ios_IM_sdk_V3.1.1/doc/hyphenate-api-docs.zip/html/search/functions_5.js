var searchData=
[
  ['endcall_3areason_3a',['endCall:reason:',['../protocol_i_e_m_call_manager-p.html#a05b306419f3d8e2f1ac7b4d77a0f1bb1',1,'IEMCallManager-p']]],
  ['errorwithdescription_3acode_3a',['errorWithDescription:code:',['../interface_e_m_error.html#a6fd5e6492c94100feb0220444201380a',1,'EMError']]]
];
